public class MyFirstProgram {
    public static void main(String[] args) {
    System.out.println("Hello, world!");
    System.out.println("I am learning to program in Java.");
    System.out.println("I hope it is a lot of fun!\n");
    System.out.println("I hope I get a good grade!\n");
    System.out.println("Maybe I'll change my major to computer science.");
    }
    }