public class Problem10 {
    public static void main(String[] args) {
        // System.out.println(toExponent(5, 4));
        double x = 2;
        double y = 12.3 * toExponent(x, 4) - 9.1 * toExponent(x, 3) + 19.3 * toExponent(x, 2) - 4.6 * x + 34.2;
        System.out.println(y);
    }

    public static double toExponent(double numb1, double exponent) {

        double result = 1;
        for (int i = 0; i < exponent; i++) {
            result = result * numb1;
        }
        return result;
    }

}
