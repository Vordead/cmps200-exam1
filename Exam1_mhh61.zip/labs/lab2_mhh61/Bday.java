public class Bday {
    public static void main(String[] args) {
        int month1 = 4;
        int day1 = 2;
        int month2 = 1;
        int day2 = 3;
        System.out.println("My birthday is " + month1 + "/" + day1 + ", and Alex's is " + month2 + "/" + day2+".");
    }
}
