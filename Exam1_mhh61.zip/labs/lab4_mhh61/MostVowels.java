package com.company.labs.lab4;

import java.util.Scanner;

public class MostVowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of Strings: ");
        int numb = scanner.nextInt();
        String max ="";
        int count = 0;
        for (int i = 0; i < numb; i++) {
            String temp = scanner.next();
            if(countVowels(temp)>countVowels(max)){
                max = temp;
                count = countVowels(temp);
            }
        }
        System.out.print(max+" "+count);
    }


    public static int countVowels(String str) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'o' || str.charAt(i) == 'i' || str.charAt(i) == 'u') {
                count++;
            }
        }
        return count;
    }

}
