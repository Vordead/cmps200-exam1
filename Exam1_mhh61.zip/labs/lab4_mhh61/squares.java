package com.company.labs.lab4;

public class squares {
    public static void main(String[] args) {
        for (int i = 1; i < 6; i++) {
            System.out.println("2 times " + i + " = " + 2 * i);
        }
    }
}