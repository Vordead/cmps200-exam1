package com.company.labs.lab4;

public class SlashFigureModified {
    public static void main(String[] args) {
        int n=4;
        for (int i = 0, z = n*2 -1; i < n; i++, z -= 2) {
            for (int l = 0; l < i; l++) {
                System.out.print("\\\\");
            }
            for (int e = 0; e < z; e++) {
                System.out.print("!!");
            }
            for (int r = 0; r < i; r++) {
                System.out.print("//");
            }
            System.out.println();
        }
    }
}