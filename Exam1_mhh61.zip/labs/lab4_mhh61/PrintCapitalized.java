package com.company.labs.lab4;

import java.util.Scanner;

public class PrintCapitalized {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String str = scanner.nextLine();
        boolean foundSpace = false;
        System.out.print(str.toUpperCase().charAt(0));
        for (int i = 1; i < str.length(); i++) {
            if (str.charAt(i) == ' ') {
                foundSpace = true;
            }
            if (foundSpace && str.charAt(i) != ' ') {
                System.out.print(str.toUpperCase().charAt(i));
                foundSpace = false;
            } else {
                System.out.print(str.charAt(i));
            }
        }
    }
}
