package com.company.labs.lab4;

public class SlashFigure {
    public static void main(String[] args) {
        for (int i = 0, z = 11; i < 6; i++, z -= 2) {
            for (int l = 0; l < i; l++) {
                System.out.print("\\\\");
            }
            for (int e = 0; e < z; e++) {
                System.out.print("!!");
            }
            for (int r = 0; r < i; r++) {
                System.out.print("//");
            }
            System.out.println();
        }

    }

}
