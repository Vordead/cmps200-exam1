package com.company.labs.lab6;

import java.util.Scanner;

public class RectangularBoxes {
    public static void main(String[] args) {
        int n = Integer.parseInt(args[0]);
        System.out.println();
        System.out.println(n);
        int height;
        int width;
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < n; i++) {
            System.out.println("Enter Height and Width\n");
            height = scanner.nextInt();
            width = scanner.nextInt();
            drawRectangle(height, width);
        }
    }

    static void drawRectangle(int height, int width) {
        for (int h = 0; h < height; h++) {
            if (h == 0 || h == height - 1)
                System.out.print('+');
            else System.out.print('|');
            for (int w = 0; w < width; w++) {
                System.out.print('-');
            }
            if (h == 0 || h == height - 1)
                System.out.println('+');
            else System.out.println('|');
        }
    }
}
