package com.company.labs.lab6;

public class Flag {
    public static void main(String[] args) {
        drawChar('+');
        drawFlag('$');
        drawChar('+');

    }
    static void drawChar(char myChar) {
        for (int j = 0; j < 3; j++) {
            for (int i = 0; i < 31; i++) {
                System.out.print(myChar);
            }
            System.out.println();
        }
    }

    static void drawFlag(char myChar) {
        for (int i = 0, j = 13; i < 7; i++, j--) {
            System.out.print('|');
            //draw left space
            for (int ls = j; ls > 0; ls--) {
                System.out.print(' ');
            }
            System.out.print('/');
            for (int k = 0; k < 2 * (i) + 1; k++) {
                System.out.print(myChar);
            }
            System.out.print('\\');

            //draw right space
            for (int ls = 13; ls > i; ls--) {
                System.out.print(' ');
            }
            System.out.print('|');
            System.out.println();

        }
        for (int z = 0, y = 2; z < 2; z++, y--) {
            System.out.print('|');
            for (int s = 0; s < 11; s++) {
                System.out.print(' ');
            }
            System.out.print('|');

            for (int h = 0; h < 5; h++) {
                System.out.print(myChar);
            }
            System.out.print('|');
            for (int s = 0; s < 11; s++) {
                System.out.print(' ');
            }
            System.out.print('|');

            System.out.println();
        }
    }


}
