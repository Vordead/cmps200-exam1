package com.company.labs.lab6;

public class Interest {
    public static void main(String[] args) {
        int n = 5;
        double result = computeYearlyIncome(1000, 10);
        System.out.printf("Year %d:  $%.2f\n", 1, result);
        for (int i = 2; i < n + 1; i++) {
            result = computeYearlyIncome(result, 10);
            System.out.printf("Year %d:  $%.2f\n", i, result);
        }
    }

    public static double computeYearlyIncome(double amount, double rate) {
        double result = amount;
        result = result + result / rate;
        return result;
    }
}
