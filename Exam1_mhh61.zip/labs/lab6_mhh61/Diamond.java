package com.company.labs.lab6;

public class Diamond {
    public static void main(String[] args) {
        int size = 6;
        char insideDiamond = '+';
        for (int i = 0, j = size; i < size + 1; i++, j--) {
            //draw left spaces
            for (int ls = j; ls > 0; ls--) {
                System.out.print(' ');
            }

            System.out.print('/');
            //draw char
            for (int k = 0; k < i * 2; k++) {
                System.out.print(insideDiamond);
            }

            System.out.print('\\');
            System.out.println();
        }


        for (int i = 0, j = size; i < size + 1; i++, j--) {
            //draw left spaces
            for (int ls = size; ls > j; ls--) {
                System.out.print(' ');
            }

            System.out.print('\\');
            //draw char
            for (int k = 0; k < j * 2; k++) {
                System.out.print(insideDiamond);
            }

            System.out.print('/');
            System.out.println();
        }
    }
}
