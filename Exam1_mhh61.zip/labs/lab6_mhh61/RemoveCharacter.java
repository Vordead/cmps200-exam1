package com.company.labs.lab6;

public class RemoveCharacter {
    public static void main(String[] args) {

        int N = Integer.parseInt(args[0]);
        for (int i = 0; i < N; i++) {
            String str = args[1 + 3 * i];
            char c = args[2 + 3 * i].charAt(0);
            int n = Integer.parseInt(args[3 + 3 * i]);
            System.out.println(removeCharacter(str, c, n));
        }
    }

    public static String removeCharacter(String str, char c, int n) {
        StringBuilder stringBuilder = new StringBuilder(str);
        System.out.println("stringBuilder is " + stringBuilder + " char is " + c);
        if (n == 0) return str;
        for (int i = 0; i < stringBuilder.length(); i++) {
            System.out.println("comparing " + stringBuilder.charAt(i) + " and " + c);
            if (stringBuilder.charAt(i) == c) {
                stringBuilder.deleteCharAt(i);
                n--;
                i--;
            }
            if (n == 0) return stringBuilder.toString();
        }
        return stringBuilder.toString();
    }
}
