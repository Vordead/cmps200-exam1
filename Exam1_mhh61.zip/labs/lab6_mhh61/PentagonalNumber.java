package com.company.labs.lab6;

public class PentagonalNumber {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 1; i < 51; i++) {
            System.out.printf("%-4d ", (i * i + sum));
            sum += i;
            if (i % 10 == 0) System.out.println();
        }
    }
}
