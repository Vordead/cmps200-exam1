package com.company.labs.lab6;

import java.util.Scanner;

public class FermatPrimesCount {
    public static void main(String[] args) {
        int countPrime = 0;
        int countSpecial = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an interval (2 +ve integers): ");
        int firstInterval = scanner.nextInt();
        int secondInterval = scanner.nextInt();
        for (int p = firstInterval; p < secondInterval; p++) {
            if (isPrime(p)) {
                countPrime++;
                if ((p - 1) % 4 == 0) {
                    countSpecial++;
                }
            }
        }
        System.out.println("Number of primes within this interval = " + countPrime);
        System.out.println(countSpecial + " of them can be expressed as a sum of two squares");
    }

    static boolean isPrime(int n) {
        if (n <= 1)
            return false;

        else if (n == 2)
            return true;

        else if (n % 2 == 0)
            return false;

        for (int i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i == 0)
                return false;
        }
        return true;
    }
}
