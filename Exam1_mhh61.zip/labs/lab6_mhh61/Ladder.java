package com.company.labs.lab6;

public class Ladder {
    public static void main(String[] args) {
        drawLadder(5);
    }

    static void drawVertical() {
        for (int i = 0; i < 2; i++) {
            System.out.println("|      |");
        }
    }

    static void drawPattern() {
        System.out.println("[*%%%%*]");
    }

    static void  drawLadder(int size){
        System.out.println("^------^");
        for(int i=1;i<size;i++){
            drawVertical();
            drawPattern();
        }
        System.out.println("v      v");
        System.out.println("v      v");
    }
}
