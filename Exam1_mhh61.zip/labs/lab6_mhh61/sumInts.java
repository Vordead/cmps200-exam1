package com.company.labs.lab6;

import java.util.Scanner;

public class sumInts {
    public static void main(String[] args) {
        System.out.print("Enter a positive integer: ");
        Scanner scanner = new Scanner(System.in);
        int k = scanner.nextInt();
        for (int i = 0; i <= k; i++)
            System.out.println(giveSumTill(i));
    }

    public static int giveSumTill(int i) {
        int sum = 0;
        for (int j = 1; j <= i; j++) {
            sum += j;
        }
        return sum;
    }
}
