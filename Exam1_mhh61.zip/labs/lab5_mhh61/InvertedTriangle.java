package com.company.labs.lab5;

public class InvertedTriangle {
    public static void main(String[] args) {
        for (int i = 0; i < 4; i++) System.out.print("- ");
        System.out.println();
        for (int i = 0, y = 6; i < 4; i++, y-=2) {
            for (int j = 0; j < i; j++) System.out.print(" ");
            System.out.print("\\");
            for (int z = 0; z < y; z++) System.out.print(" ");
            System.out.println("/");
            System.out.println();
        }
    }
}
