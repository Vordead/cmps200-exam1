package com.company.labs.lab5;

import java.util.Scanner;

public class LongestAlphabeticalSubstring {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input String: ");
        String str = scanner.next();
        String temp = "" + str.charAt(0);
        String longest = "";
        for (int i = 1; i < str.length(); i++) {
            if (str.charAt(i) >= temp.charAt(temp.length() - 1)) {
                temp += str.charAt(i);
            } else {
                if (temp.length() > longest.length()) {
                    longest = temp;
                }
                temp = "" + str.charAt(i);
            }
        }
        System.out.print("Longest alphabetical substring: " + longest);
    }
}