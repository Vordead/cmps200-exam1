package com.company.labs.lab5;

public class output1 {
    public static void main(String[] args) {
        method1();
    }
    public static void method1() {
        for (int i = 1; i <= 5; i++) {
            if (i % 2 != 0) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("* ");
                }
            } else {
                for (int j = 1; j <= i; j++) {
                    System.out.print(j + " ");
                }
            }
            System.out.println();
        }
    }
}

/*
Output is

*
1 2
* * *
1 2 3 4
* * * * *


 */