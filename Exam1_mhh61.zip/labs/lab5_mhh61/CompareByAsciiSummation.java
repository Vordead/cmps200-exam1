package com.company.labs.lab5;

import java.util.Scanner;

public class CompareByAsciiSummation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("First String: ");
        String str1 = scanner.next();
        System.out.print("Second String: ");
        String str2 = scanner.next();
        int count1 = 0;
        int count2 = 0;
        for (int i = 0; i < str1.length(); i++)
            count1 += str1.charAt(i);
        for (int i = 0; i < str2.length(); i++)
            count2 += str2.charAt(i);
        if (count1 > count2)
            System.out.print(str1 + " is bigger");
        else System.out.print(str2 + " is bigger");
    }
}
