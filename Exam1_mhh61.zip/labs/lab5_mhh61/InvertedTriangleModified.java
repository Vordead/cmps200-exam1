package com.company.labs.lab5;

public class InvertedTriangleModified {
    public static void main(String[] args) {
        int n=6 ;
        for (int i = 0; i < n; i++) System.out.print("- ");
        System.out.println();
        for (int i = 0, y = n+(n-2); i < n; i++, y-=2) {
            for (int j = 0; j < i; j++) System.out.print(" ");
            System.out.print("\\");
            for (int z = 0; z < y; z++) System.out.print(" ");
            System.out.println("/");
            System.out.println();
        }
    }
}
