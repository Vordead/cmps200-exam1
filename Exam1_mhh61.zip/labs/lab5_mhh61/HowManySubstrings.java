package com.company.labs.lab5;

import java.util.Scanner;

public class HowManySubstrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Long string: ");
        String str1 = scanner.next();
            System.out.print("Short string: ");
        String str2 = scanner.next();
        int count = 0;
        while (str1.contains(str2)) {
            System.out.println("Short string appears in long string at index " + (str1.indexOf(str2) + count * str2.length()));
            count++;
            str1 = str1.substring(str1.indexOf(str2) + str2.length());
        }
        System.out.print("Short string appears in long string " + count + " times");
    }
}