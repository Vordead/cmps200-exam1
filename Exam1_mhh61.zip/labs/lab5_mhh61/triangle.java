package com.company.labs.lab5;

public class triangle {
    public static void main(String[] args) {
        for (int i = 0, j = 5; i < 5; i++, j--) {
            for (int k = 0; k < j; k++) {
                System.out.print("  ");
            }
            if (i % 2 == 0) {
                for (int y = 0; y < i + 1; y++) {
                    System.out.print("* ");
                }
            } else {
                for (int k = 0; k < i + 1; k++) {
                    System.out.print("# ");
                }
            }
            System.out.println();
        }
    }
}
