package com.company.labs.lab3;

import java.util.Scanner;

public class DOW {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input a number: ");
        final int d0 = scanner.nextInt();
        final String day = switch (d0) {
            case 1 -> "Monday";
            case 2 -> "Tuesday";
            case 3 -> "Wednesday";
            case 4 -> "Thursday";
            case 5 -> "Friday";
            case 6 -> "Saturday";
            case 7 -> "Sunday";
            default -> "Invalid input, please enter a number between 1 and 7";
        };
        if (d0 < 1 || d0 > 7)
            System.out.print(day);
        else
            System.out.print("The day corresponding to the entered date was a " + day);
    }
}
