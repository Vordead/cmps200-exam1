package com.company.labs.lab3;

import java.util.Scanner;

public class Greatest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input first number: ");
        int max = scanner.nextInt();
        System.out.print("Input second number: ");
        final int secondNum = scanner.nextInt();
        if(secondNum>max) max = secondNum;
        System.out.print("Input third number: ");
        final int thirdNum = scanner.nextInt();
        if(thirdNum>max) max = thirdNum;
        System.out.print("The greatest: "+max);
    }
}
