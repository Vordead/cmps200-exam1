package com.company.labs.lab3;

import java.util.Scanner;

public class Minutes {
    public static void main(String[] args) {
        double minutesInYear = 60 * 24 * 365;
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the number of minutes: ");
        double numberOfMinutes = input.nextDouble();
        long years = (long) (numberOfMinutes / minutesInYear);
        int days = (int) (numberOfMinutes / 60 / 24) % 365;
        System.out.println((int) numberOfMinutes + " minutes is approximately " + years + " years and " + days + " days");
    }
}
