package com.company.labs.lab3;

import java.util.Scanner;

public class VOC {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Input a character: ");
        final String input = scanner.next();
        if (input.length() == 1) {
            final char myChar = input.charAt(0);
            if (Character.isAlphabetic(myChar)) {
                switch (myChar) {
                    case 'a', 'e', 'i', 'o', 'u' -> System.out.println("The input is a vowel letter");
                    default -> System.out.println("The input is a consonant letter");
                }
            } else {
                System.out.print("Invalid input, please enter an alphabet character");
            }
        } else {
            System.out.print("Invalid input, please enter a single character");
        }
    }
}
