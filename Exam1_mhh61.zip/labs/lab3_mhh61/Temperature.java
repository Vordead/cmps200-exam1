package com.company.labs.lab3;

import java.util.Scanner;

public class Temperature {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter temperature in degrees Fahrenheit: ");
        final float fahrenheitTemp =  scanner.nextFloat();
        final float celsiusTemp = (fahrenheitTemp - 32) * 5/9;
        System.out.print(celsiusTemp);
    }
}
