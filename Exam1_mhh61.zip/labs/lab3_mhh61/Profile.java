package com.company.labs.lab3;

import java.util.Scanner;

public class Profile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to CMPS 200");
        System.out.print("Enter your name: ");
        final String name = scanner.nextLine();
        System.out.print("Enter your ID: ");
        final long studentID = scanner.nextLong();
        System.out.print("Enter your midterm exam grade: ");
        final float midtermGrade = scanner.nextFloat();
        System.out.print("Enter your final exam grade: ");
        final float finalGrade = scanner.nextFloat();
        System.out.println("---");
        System.out.printf("Student %s (%d)\n",name,studentID);
        System.out.print("Overall grade "+(midtermGrade*0.3 + finalGrade*0.7));
    }
}
