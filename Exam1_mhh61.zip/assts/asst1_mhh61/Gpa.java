public class Gpa {
    public static void main(String[] args) {
        final double myGPA =  (3 + 4 + 3 + 2 + 4)/5.0;
        System.out.println(myGPA);
    }
}
