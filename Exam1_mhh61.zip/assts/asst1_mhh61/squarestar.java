public class squarestar {
    public static void main(String[] args) {
        for(int i=0;i<5;++i){
            printLine();
        }  
    }
    public static void printLine() {
       System.out.println("*\t*\t*\t*\t*");
    }
}
