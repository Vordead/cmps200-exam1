public class printAUB {
    public static void main(String[] args) {
        System.out.println("  A A A  \t\tU       U\t\tB B B");
        System.out.println(" A     A \t\tU       U\t\tB      B");
        System.out.println("A       A\t\tU       U\t\tB      B");
        System.out.println("A       A\t\tU       U\t\tB B B");
        System.out.println("A A A A A\t\tU       U\t\tB      B");
        System.out.println("A       A\t\tU       U\t\tB      B");
        System.out.println("A       A\t\tU       U\t\tB      B");
        System.out.println("A       A\t\t  U U U  \t\tB B B");
    }
}
