public class Heyo{
    public static void main(String[] args) {
        System.out.println("Hello!\nHow\nare you?");  
    }
}