package com.company.assts.asst4;

import java.util.Scanner;

public class RightTriangle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the height of the triangle: ");
        int n = scanner.nextInt();
        for (int i = 1; i < n + 1; i++) {
            System.out.println("*".repeat(i));
        }
    }
}
