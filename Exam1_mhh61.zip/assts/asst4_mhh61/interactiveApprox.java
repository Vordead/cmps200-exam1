////pb5 part 1
//
//package com.company.assts.asst4;
//
//import java.util.Scanner;
//
//public class interactiveApprox {
//    public static void main(String[] args) {
//        int numberOfTerms=0;
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter number of n: ");
//        double n = scanner.nextDouble();
//        double sum = 0;
//        for (int i = 0; i < n; i++) {
//            sum += (Math.pow(-1, i)) / (2 * i + 1);
//            System.out.println(sum);
//            numberOfTerms++;
//        }
//        double pi = sum * 4;
//        System.out.println(pi);
//    }
//}


////part 2
//package com.company.assts.asst4;
//
//import java.util.Scanner;
//
//public class interactiveApprox {
//    public static void main(String[] args) {
//        String pi = "3.141592";
//        Scanner scanner = new Scanner(System.in);
//        System.out.println("Enter number of n: ");
//        double n = scanner.nextDouble();
//        double sum = 0;
//        double tempPI = 0;
//        int numberOfTerms = 0;
//        for (int i = 0; i < n; i++) {
//            sum += (Math.pow(-1, i)) / (2 * i + 1);
//            tempPI = sum * 4;
//            numberOfTerms++;
//            if (String.format("%.6f", tempPI).equals(pi)) {
//                break;
//            }
//        }
//        System.out.println(Math.PI);
//        System.out.printf("%.6f%n", tempPI);
//        System.out.println(numberOfTerms);
//    }
//}


//part 3
package com.company.assts.asst4;

import java.util.Scanner;

public class interactiveApprox {
    public static void main(String[] args) {
        double sum = 0;
        double percentError;
        System.out.println("N       Error");
        System.out.println("---     ------");
        for (int i = 0; i <= 100; i++) {
            sum += Math.pow(-1.0, i) / (2 * i + 1);
            if (i % 2 == 0)
                percentError = Math.abs((sum * 4) / Math.PI * 100) - 100;
            else
                percentError = 100 - Math.abs((sum * 4) / Math.PI * 100);
            System.out.printf("%d       %.2f%s \n", i, percentError, "%");
        }
    }
}