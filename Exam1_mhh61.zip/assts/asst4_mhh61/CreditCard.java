package com.company.assts.asst4;

/**
 * PART A
 */


//public class CreditCard {
//    public static void main(String[] args) {
//        double balance = 42; //outstanding balance on the credit card
//        double annualInterestRate = 0.2; //represent the annual interest rate
//        double monthlyPaymentRate = 0.04; //denote the minimum monthly payment rate
//        double monthlyInterestRate = annualInterestRate / 12;
//        double updatedMonthlyBalance = 0;
//        for (int i = 1; i < 13; i++) {
//            double minimumMonthlyPayment = monthlyPaymentRate * balance;
//            double monthlyUnpaidBalance = balance - minimumMonthlyPayment;
//            updatedMonthlyBalance = monthlyUnpaidBalance + monthlyInterestRate * monthlyUnpaidBalance;
//            balance = updatedMonthlyBalance;
//        }
//        System.out.print("Remaining balance: " + String.format("%.2f", updatedMonthlyBalance));
//
//    }
//}


/**
 * PART B
 */

//package com.company.assts.asst4;
//
//public class CreditCard {
//    public static void main(String[] args) {
//        double balance = 3926; //outstanding balance on the credit card
//        double originalBalance = balance;
//        double annualInterestRate = 0.2; //represent the annual interest rate
//        double monthlyInterestRate = annualInterestRate / 12;
//        double updatedMonthlyBalance = 0;
//        double monthlyPaymentRate = 10;
//        while (true) {
//            for (int i = 1; i < 13; i++) {
//                double monthlyUnpaidBalance = balance - monthlyPaymentRate;
//                updatedMonthlyBalance = monthlyUnpaidBalance + monthlyInterestRate * monthlyUnpaidBalance;
//                balance = updatedMonthlyBalance;
//            }
//            if (balance < 0) {
//                System.out.println("Remaining balance: " + String.format("%.2f", updatedMonthlyBalance));
//                System.out.print("Lowest Payment: " + monthlyPaymentRate);
//                break;
//            }
//            balance = originalBalance;
//            monthlyPaymentRate += 10;
//        }
//
//    }
//}


/**
 * PART C
 */

public class CreditCard {
    public static void main(String[] args) {
        method1();
    }
    static void method1() {
        double annualInterestRate;
        double monthlyPaymentRate;
        double balance = 999999;
        annualInterestRate = 0.18;
        double originalBalance = balance;
        for (int i = 1; i <= 12; i++) {
            double currentBalance = originalBalance;
            originalBalance = currentBalance + (annualInterestRate / 12.0) * currentBalance;
        }
        double upperBound = originalBalance / 12.0;
        double lowerBound = balance / 12.0;
        for (monthlyPaymentRate = lowerBound; monthlyPaymentRate < upperBound; monthlyPaymentRate += 0.01) {
            originalBalance = balance;
            for (int i = 1; i <= 12; i++) {
                double currentBalance = originalBalance - monthlyPaymentRate;
                originalBalance = currentBalance + (annualInterestRate / 12.0) * currentBalance;
            }
            if (originalBalance <= 0.001) {
                System.out.printf("Lowest Payment: %.2f", monthlyPaymentRate);
                break;
            }
        }
    }
}