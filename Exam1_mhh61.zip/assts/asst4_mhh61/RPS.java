package com.company.assts.asst4;

import java.util.Random;
import java.util.Scanner;

public class RPS {
    public static void main(String[] args) {
        System.out.println("Please Enter:\nR for Rock\nP for Paper\nS for Scissors");
        int myWin = 0, myLose = 0;
        int tie = 0;
        Scanner scanner = new Scanner(System.in);
        char[] arr = {'R', 'P', 'S'};
        Random random = new Random();
        while (true) {
            System.out.println("Enter your move (Type X to end game): ");
            char pcMove = arr[random.nextInt(arr.length)];
            char myMove = scanner.next().charAt(0);
            if (myMove == 'X') {
                System.out.println("User wins: " + myWin);
                System.out.println("User Losses: " + myLose);
                System.out.println("Ties: " + tie);
                break;
            }
            System.out.println("You played " + myMove + " and PC played " + pcMove);
            if (myMove != 'R' && myMove != 'P' && myMove != 'S') {
                System.out.println("Please pick a valid move!");
            }
            else if (myMove == pcMove) {
                tie++;
                System.out.println("It's a Tie!");
            } else if ((myMove == 'R' && pcMove == 'P') || (myMove == 'S' && pcMove == 'R') || (myMove == 'P' && pcMove == 'S')) {
                myLose++;
                System.out.println("Computer Won!");
            } else {
                myWin++;
                System.out.println("You Win!");
            }
        }
    }
}