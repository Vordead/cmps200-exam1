package com.company.assts.asst4;

import java.util.Scanner;

public class ogero {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("What plan are you subscribed to? ");
        char myPlan = scanner.next().charAt(0);
        System.out.print("How many hours have you consumed? ");
        int hoursConsumed = scanner.nextInt();
        double subPrice=0, rate = 0, price;
        int freeHours = 0;
        switch (myPlan) {
            case 'A' -> {
                subPrice = 9.95;
                freeHours = 10;
                rate = 2.00;
            }
            case 'B' -> {
                subPrice = 13.95;
                freeHours = 20;
                rate = 1.00;
            }
            case 'C' -> {
                subPrice = 19.95;
                freeHours = 40;
                rate = 0.50;
            }
            case 'D' -> subPrice = 29.95;
        }
        if (hoursConsumed <= freeHours || myPlan =='D') {
            price = subPrice;
        } else {
            price = (hoursConsumed - freeHours) * rate + subPrice;
        }
        System.out.printf("The total charges: $%.2f", price);
    }
}
