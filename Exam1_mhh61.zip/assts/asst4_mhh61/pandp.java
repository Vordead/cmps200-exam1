package com.company.assts.asst4;

public class pandp {
    public static void main(String[] args) {
        int count = 50;
        int numb = 1000001;
        while (count != 0) {
            if (isPrime(numb) && isPalindrome(numb)) {
                System.out.println(numb);
                count--;
            }
            numb++;
        }
    }

    static boolean isPrime(int n) {
        if (n <= 1)
            return false;

        else if (n == 2)
            return true;

        else if (n % 2 == 0)
            return false;

        for (int i = 3; i <= Math.sqrt(n); i += 2)
        {
            if (n % i == 0)
                return false;
        }
        return true;
    }


    static boolean isPalindrome(int n) {
        int totalDigits = (int) Math.log10(n);
        for (int i = 0; i < Math.ceil(totalDigits / 2.0); i++) {
            int firstDigit = n / (int) Math.pow(10, totalDigits - i) % 10;
            int lastDigit = (n / (int) Math.pow(10, i)) % 10;
            if (firstDigit != lastDigit) return false;
        }
        return true;
    }
}
