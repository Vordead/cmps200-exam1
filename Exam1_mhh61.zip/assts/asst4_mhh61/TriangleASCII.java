package com.company.assts.asst4;

import java.util.Scanner;

public class TriangleASCII {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the height of the triangle: ");
        int n = scanner.nextInt();
        for (int i = 0, z = n; i < n; i++) {
            if (z > n / 2) {
                System.out.print("*".repeat(i + 1));
                z--;
            } else
                for (int j = n + 1; j > i; j--) {
                    System.out.print('*');
                }
            System.out.println();
        }
    }
}