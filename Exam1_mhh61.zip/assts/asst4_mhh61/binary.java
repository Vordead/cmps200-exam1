package com.company.assts.asst4;

import java.util.Scanner;

public class binary {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter a binary number: ");
        long bin = scanner.nextLong();
        int sum = 0;
        int totalDigits = (int) Math.log10(bin);
        for (int i = 0; i < totalDigits + 1; i++) {
            int firstDigit = (int) (bin / (int) Math.pow(10, totalDigits - i) % 10);
            sum += firstDigit * Math.pow(2, totalDigits - i);
        }
        System.out.println(bin + " in binary = " + sum + " in decimal");
    }
}
