package com.company.assts.asst2;

import java.util.Scanner;

public class Order {
    public static void main(String[] args) {
        System.out.print("Enter three integers: ");
        Scanner scanner = new Scanner(System.in);
        final int a = scanner.nextInt();
        final int b = scanner.nextInt();
        final int c = scanner.nextInt();
        scanner.close();
        if (a < b && b < c)
            System.out.print("Integers are in ascending order.");

        else if (a > b && b > c)
            System.out.print("Integers are in descending order.");

        else System.out.print("Integers are not in any specific order.");

    }
}
