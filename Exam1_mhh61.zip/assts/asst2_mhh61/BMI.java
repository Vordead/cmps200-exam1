package com.company.assts.asst2;

import java.util.Scanner;

public class BMI {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        final double w = scanner.nextDouble();
        final double h = scanner.nextDouble();
        final double bmi = w / (h * h);
        if (bmi < 17.5) System.out.print("Anorexic");
        else if (bmi < 18.5) System.out.print("Underweight");
        else if (bmi >= 18.5 && bmi < 25) System.out.print("Ideal");
        else if (bmi >= 25 && bmi < 30) System.out.print("Overweight");
        else if (bmi >= 30 && bmi < 40) System.out.print("Obese");
        else System.out.print("Error");  //optional line feel free to remove

    }
}
