package com.company.assts.asst2;

import java.util.Scanner;

public class Qroots {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        float a = scanner.nextFloat();
        float b = scanner.nextFloat();
        float c = scanner.nextFloat();
        scanner.close();
        float delta = b*b - 4*a*c;
        if(delta > 0){
            float firstRoot = (float) (((-b)-Math.sqrt(delta))/(2*a));
            float secondRoot = (float) (((-b)+Math.sqrt(delta))/(2*a));
            System.out.println("First root is: "+firstRoot);
            System.out.println("Second root is: "+secondRoot);
        }
        else if(delta ==0) {
            float uniqueRoot =  (b/(2*a));
            System.out.print(uniqueRoot);
        }
        else System.out.print("No real roots exist");
    }
}
