package com.company.assts.asst2;

import java.util.Scanner;

public class Day {
    public static void main(String[] args) {
        System.out.print("Enter a date: ");
        Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();
        int d = scanner.nextInt();
        int y = scanner.nextInt();
        scanner.close();

        int y0 = y - (14 - m) / 12;
        int x = y0 + y0 / 4 - y0 / 100 + y0 / 400;
        int m0 = m + 12 * ((14 - m) / 12) - 2;
        int d0 = (d + x + (31 * m0) / 12) % 7;
        String day;
        switch (d0) {
            case 0:
                day = "Sunday";
                break;
            case 1:
                day = "Monday";
                break;
            case 2:
                day = "Tuesday";
                break;
            case 3:
                day = "Wednesday";
                break;
            case 4:
                day = "Thursday";
                break;
            case 5:
                day = "Friday";
                break;
            case 6:
                day = "Saturday";
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + d0);
        }
        System.out.print("The day corresponding to the entered date was a " + day);
    }
}
