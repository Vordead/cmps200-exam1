package com.company.assts.asst2;

public class Ruler {
    public static void main(String[] args) {
        final String a = "1 ";
        final String b = a + "2 " + a;
        final String c = b + "3 " + b;
        final String d = c + "4 " + c;
        System.out.print(a + "\n" + b + "\n" + c + "\n" + d);

    }
}
