package com.company.assts.asst2;

import java.util.Scanner;

public class Spring {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter m: ");
        final int m = scanner.nextInt();
        System.out.print("Enter d: ");
        final int d = scanner.nextInt();
        scanner.close();
        final boolean spring = ((m == 3 && (d <= 31 && d > 21) || (m == 4 && (d <= 30 && d >= 1)) || (m == 5 && (d <= 31 && d >= 1)) || (m == 6 && (d < 20 && d >= 1))));
        System.out.print(spring);

    }
}
