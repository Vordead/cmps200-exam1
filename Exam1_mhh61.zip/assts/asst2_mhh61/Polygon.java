package com.company.assts.asst2;

import java.util.Scanner;

public class Polygon {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String shape;
        final int numbOfSides = scanner.nextInt();
        scanner.close();
        switch (numbOfSides) {
            case 1 -> shape = "Line";
            case 3 -> shape = "Triangle";
            case 4 -> shape = "Rectangle";
            case 5 -> shape = "Pentagon";
            case 6 -> shape = "Hexagon";
            case 7 -> shape = "Heptagon";
            case 8 -> shape = "Octagon";
            case 9 -> shape = "Nonagon";
            case 10 -> shape = "Decagon";
            case 12 -> shape = "Dodecagon";
            default -> throw new IllegalStateException("ERROR: Unrecognized Shape");
        }
        String strMsg = String.format("A shape that has %s side(s) is a %s", numbOfSides, shape);
        System.out.print(strMsg);
    }
}
