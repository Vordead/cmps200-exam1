package com.company.assts.asst3;

public class vowels {
    public static void main(String[] args) {
        int count=0;
        String str = "ambition";
        for(int i=0;i<str.length();i++){
            if(str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'o' || str.charAt(i) == 'i' || str.charAt(i) == 'u'){
                count++;
            }
        }
        System.out.print(count);
    }
}
