package com.company.assts.asst3;

import java.util.Scanner;

public class digits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numb = scanner.nextInt();
        int totalDigits = (int) Math.log10(numb);
        for (int i = 0; i <= totalDigits; i++) {
            System.out.print((numb / (int) Math.pow(10, totalDigits - i)) % 10 + "   ");
        }
    }
}