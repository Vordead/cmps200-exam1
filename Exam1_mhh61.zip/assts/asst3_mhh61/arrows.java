package com.company.assts.asst3;

public class arrows {
    public static void main(String[] args) {
        drawArrow(5);
    }

    public static void drawArrow(int n) {
        for (int i = n, j = 0; i > 0; i--, j++) {
            printSpace(j);
            printStar(i);
            System.out.println();
        }
        for (int i = 1, j = n - 1; i < n + 1; i++, j--) {
            printSpace(j);
            printStar(i);
            if (i != n)
                System.out.println();
        }
    }

    private static void printStar(int n) {
        if (n > 0) {
            System.out.print("* ");
            printStar(n - 1);
        }
    }

    private static void printSpace(int n) {
        if (n > 0) {
            System.out.print(" ");
            printSpace(n - 1);
        }
    }
}
