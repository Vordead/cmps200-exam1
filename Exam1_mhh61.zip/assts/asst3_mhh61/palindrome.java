package com.company.assts.asst3;

import java.util.Scanner;

public class palindrome {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            String str = scanner.nextLine();
            if (str.equals("DONE")) break;
            int len = str.length();
            if (len == 1) {
                System.out.print(true);
            } else {
                boolean isPalindrome = true;
                for (int i = 0, j = len - i - 1; i < j; i++, j--) {
                    if (str.toLowerCase().charAt(i) != str.toLowerCase().charAt(j)) {
                        isPalindrome = false;
                        break;
                    }
                }
                System.out.println(str + ", " + isPalindrome);
            }
        }
    }
}
