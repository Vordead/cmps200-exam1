package com.company.assts.asst3;

public class Leap {
    public static void main(String[] args) {
        for (int i = 1900; i < 2101; i++) {
            if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0) {
                if (isPast(i)) {
                    System.out.println(i + " was a leap year");
                } else System.out.println(i + " will be a leap year");

            } else {
                if (isPast(i))
                    System.out.println(i + " was not a leap year");
                else System.out.println(i + " will not be a leap year");
            }
        }
    }

    public static boolean isPast(int i) {
        return i < 2021;
    }
}


