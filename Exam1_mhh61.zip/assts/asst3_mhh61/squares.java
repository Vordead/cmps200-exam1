package com.company.assts.asst3;

public class squares {
    public static void main(String[] args) {
        for(int i=1;i<11;i++){
            System.out.print(i*i+" ");
            if(i==1){
                System.out.print(" ");
            }
        }
    }
}
