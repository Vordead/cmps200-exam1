package com.company.assts.asst5;

import java.util.Scanner;

public class LengthConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            Object[] arr = input();
            output((int) arr[0], (double) arr[1], (double) arr[2]);
            System.out.println("Y or y continues, any other character quits");
            char ans = scanner.next().charAt(0);
            if (ans == 'Y' || ans == 'y') break;
        }
        scanner.close();
    }

    public static Object[] input() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter feet as an integer: ");
        int feet = scanner.nextInt();
        System.out.print("Enter inches as a double: ");
        double inches = scanner.nextDouble();
        return new Object[]{feet, inches, calculate(feet, inches)};
    }

    public static double calculate(double feet, double inches) {
        return feet * 0.3048 + inches * 0.0254;
    }

    public static void output(int feet, double inches, double result) {
        System.out.printf("the value of feet, inches %d, %f\nconverted to meters, centimeters is %f\n", feet, inches, result);
    }
}