package com.company.assts.asst5;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Histogram {
    public static void main(String[] args) {
        Map<Character, Integer> hashMap = new HashMap<Character, Integer>();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Sentence: ");
        String str = scanner.nextLine();
        for (int i = 0; i < str.length(); i++) {
            hashMap.merge(str.toLowerCase().charAt(i), 1, Integer::sum);
        }
        hashMap.remove(' ');
        System.out.println("Histogram:");
        for (Map.Entry<Character, Integer> set :
                hashMap.entrySet()) {
            histogram(set.getKey(), set.getValue());
        }
    }

    public static void histogram(char c, int n) {
        System.out.printf("%s: %d | %s\n", c, n, "*".repeat(n));
    }
}
