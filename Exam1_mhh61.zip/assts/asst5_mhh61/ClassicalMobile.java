package com.company.assts.asst5;

import java.util.Scanner;

public class ClassicalMobile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Please enter an SMS Message: ");
        String str = scanner.nextLine();
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < str.length(); i++)
            stringBuilder.append(alphaToKey(str.charAt(i)));
        System.out.print("Encoded Message is: " + stringBuilder);
    }

    public static String alphaToKey(char l) {
        int count = 1;
        while (true) {
            switch (Character.toUpperCase(l)) {
                case ' ' -> {return "0";}
                case 'A' -> {return "2".repeat(count);}
                case 'D' -> {return "3".repeat(count);}
                case 'G' -> {return "4".repeat(count);}
                case 'J' -> {return "5".repeat(count);}
                case 'M' -> {return "6".repeat(count);}
                case 'P' -> {return "7".repeat(count);}
                case 'T' -> {return "8".repeat(count);}
                case 'W' -> {return "9".repeat(count);}
                default -> {
                    l--;
                    count++;
                }
            }
        }
    }
}