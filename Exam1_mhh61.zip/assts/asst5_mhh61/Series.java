package com.company.assts.asst5;

public class Series {
    public static void main(String[] args) {
        int count = 0;
        while (computeSum(count) < 2 - Math.pow(10, -6))
            count++;
        System.out.println("Smallest value of n is: " + count);
    }

    public static double computeSum(int n) {
        double sum = 0;
        for (int i = 0; i < n + 1; i++)
            sum += Math.pow((1 / 2.0), i);
        return sum;
    }
}
